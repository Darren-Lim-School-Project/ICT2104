/*
 * UART.h
 *
 *  Created on: 18 Oct 2021
 *      Author: darre
 */

#ifndef UART_H_
#define UART_H_


init_UART();


#endif /* UART_H_ */
